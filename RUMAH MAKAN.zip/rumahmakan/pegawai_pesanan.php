<?php
session_start();
if (empty($_SESSION['username']) or empty($_SESSION['level'])) {
    echo "<script>alert('Maaf, untuk mengakses halaman ini, anda harus login terlebih dahulu, terima kasih');document.location='index.php'</script>";
}

?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="index.css">
    <link rel="stylesheet" type="text/css" href="fontawesome/css/all.min.css">

    <title>RUMAH MAKAN KITA</title>
  </head>
  <body>
  <!-- Jumbotron -->
      <div class="jumbotron jumbotron-fluid text-center">
        <div class="container">
          <h1 class="display-4"><span class="font-weight-bold">PESAN MAKANAN RUMAH MAKAN KITA</span></h1>
          <hr>
          <p class="lead font-weight-bold">Silahkan Pesan Menu  <br> 
          Enjoy Your Food</p>
        </div>
      </div>
  <!-- Akhir Jumbotron -->

  <!-- Navbar -->
      <nav class="navbar navbar-expand-lg  bg-dark">
        <div class="container">
        <a class="navbar-brand text-white" href="pegawai_home.php"><strong>RUMAH MAKAN</strong> KITA</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link mr-4" href="pegawai_home.php">HOME</a>
            </li>
            <li class="nav-item">
              <a class="nav-link mr-4" href="pegawai_daftarmenu.php">DAFTAR MENU</a>
            </li>
            <li class="nav-item">
              <a class="nav-link mr-4" href="pegawai_pesanan.php">PESANAN</a>
            </li>
            <li class="nav-item">
              <a class="nav-link mr-4" href="logout.php">LOGOUT</a>
            </li>
          </ul>
        </div>
       </div> 
      </nav>
  <!-- Akhir Navbar -->
</body>
</html>
<?php
	//Koneksi Database
	$server = "localhost";
	$user = "root";
	$pass = "";
	$database = "dbmakanan";

	$koneksi = mysqli_connect($server, $user, $pass, $database)or die(mysqli_error($koneksi));

	//jika tombol simpan diklik
	if(isset($_POST['bsimpan']))
	{
		//Pengujian Apakah data akan diedit atau disimpan baru
		if($_GET['hal'] == "edit")
		{
			//Data akan di edit
			$edit = mysqli_query($koneksi, "UPDATE pesanan set
											 	no_meja = '$_POST[tno_meja]',
											 	nama_pesanan = '$_POST[tnama_pesanan]',
												jumlah_pesanan = '$_POST[tjumlah_pesanan]',
											 	status_pesanan = '$_POST[tstatus_pesanan]'
											 WHERE id_pesanan = '$_GET[id]'
										   ");
			if($edit) //jika edit sukses
			{
				echo "<script>
						alert('Edit data suksess!');
						document.location='index.php';
				     </script>";
			}
			else
			{
				echo "<script>
						alert('Edit data GAGAL!!');
						document.location='index.php';
				     </script>";
			}
		}
		else
		{
			//Data akan disimpan Baru
			$simpan = mysqli_query($koneksi, "INSERT INTO pesanan (no_meja, nama_pesanan, jumlah_pesanan, status_pesanan)
										  VALUES ('$_POST[tno_meja]', 
										  		 '$_POST[tnama_pesanan]', 
										  		 '$_POST[tjumlah_pesanan]', 
										  		 '$_POST[tstatus_pesanan]')
										 ");
			if($simpan) //jika simpan sukses
			{
				echo "<script>
						alert('Simpan data suksess!');
						document.location='index.php';
				     </script>";
			}
			else
			{
				echo "<script>
						alert('Simpan data GAGAL!!');
						document.location='index.php';
				     </script>";
			}
		}


		
	}


	//Pengujian jika tombol Edit / Hapus di klik
	if(isset($_GET['hal']))
	{
		//Pengujian jika edit Data
		if($_GET['hal'] == "edit")
		{
			//Tampilkan Data yang akan diedit
			$tampil = mysqli_query($koneksi, "SELECT * FROM pesanan WHERE id_pesanan = '$_GET[id]' ");
			$data = mysqli_fetch_array($tampil);
			if($data)
			{
				//Jika data ditemukan, maka data ditampung ke dalam variabel
				$vnomeja = $data['no_meja'];
				$vnamapesanan = $data['nama_pesanan'];
				$vjumlahpesanan = $data['jumlah_pesanan'];
				$vstatuspesanan = $data['status_pesanan'];
			}
		}
		else if ($_GET['hal'] == "hapus")
		{
			//Persiapan hapus data
			$hapus = mysqli_query($koneksi, "DELETE FROM pesanan WHERE id_pesanan = '$_GET[id]' ");
			if($hapus){
				echo "<script>
						alert('Hapus Data Suksess!!');
						document.location='index.php';
				     </script>";
			}
		}
	}

?>

<!DOCTYPE html>
<html>
<head>
	<title>Pesanan</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
</head>
<body>
<div class="container">

	<h1 class="text-center">Data Pemesanan Makanan</h1>

	<!-- Awal Card Form -->
	<div class="card mt-3">
		<div class="card-header bg-primary text-white">
		Input Data Pesanan
	  </div>
	  <div class="card-body">
	    <form method="post" action="">
	    	<div class="form-group">
	    		<label>No. Meja</label>
	    		<input type="text" name="tno_meja" value="<?=@$vnomeja?>" class="form-control" placeholder="Masukkan nomor meja!" required>
	    	</div>
	    	<div class="form-group">
	    		<label>Pesanan</label>
	    		<input type="text" name="tnama_pesanan" value="<?=@$vnamapesanan?>" class="form-control" placeholder="Masukkan nama pesanan!" required>
	    	</div>
	    	<div class="form-group">
	    		<label>Jumlah Pesanan</label>
	    		<textarea class="form-control" name="tjumlah_pesanan"  placeholder="Masukkan jumlah pesanan!"><?=@$vjumlahpesanan?></textarea>
	    	</div>
	    	<div class="form-group">
	    		<label>Status Pesanan</label>
				<textarea class="form-control" name="tstatus_pesanan"  placeholder="Masukkan status pesanan!"><?=@$vstatuspesanan?></textarea>
	    	</div>

	    	<button type="submit" class="btn btn-success" name="bsimpan">Simpan</button>
	    	<button type="reset" class="btn btn-danger" name="breset">Kosongkan</button>

	    </form>
	  </div>
	</div>
	<!-- Akhir Card Form -->

	<!-- Awal Card Tabel -->
	<div class="card mt-3">
	  <div class="card-header bg-success text-white">
	    Daftar Pesanan
	  </div>
	  <div class="card-body">
	    
	    <table class="table table-bordered table-striped">
	    	<tr>
	    		<th>No.</th>
	    		<th>No. Meja</th>
	    		<th>Nama Pesanan</th>
	    		<th>Jumlah Pesanan</th>
	    		<th>Status Pesanan</th>
	    		<th>Aksi</th>
	    	</tr>
	    	<?php
	    		$no = 1;
	    		$tampil = mysqli_query($koneksi, "SELECT * from pesanan order by id_pesanan desc");
	    		while($data = mysqli_fetch_array($tampil)) :

	    	?>
	    	<tr>
	    		<td><?=$no++;?></td>
	    		<td><?=$data['no_meja']?></td>
	    		<td><?=$data['nama_pesanan']?></td>
	    		<td><?=$data['jumlah_pesanan']?></td>
	    		<td><?=$data['status_pesanan']?></td>
	    		<td>
	    			<a href="index.php?hal=edit&id=<?=$data['id_pesanan']?>" class="btn btn-warning"> Edit </a>
	    			<a href="index.php?hal=hapus&id=<?=$data['id_pesanan']?>" 
	    			   onclick="return confirm('Apakah yakin ingin menghapus data ini?')" class="btn btn-danger"> Hapus </a>
	    		</td>
	    	</tr>
	    <?php endwhile; //penutup perulangan while ?>
	    </table>

	  </div>
	</div>
	<!-- Akhir Card Tabel -->

</div>

<script type="text/javascript" src="js/bootstrap.min.js"></script>
</body>
</html>